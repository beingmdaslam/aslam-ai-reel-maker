export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }

  const apiKey = process.env.SARVAM_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "SARVAM_API_KEY is missing. Add it in Netlify environment variables and redeploy." },
      { status: 500 }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid request body." }, { status: 400 });
  }

  const text = String(body.text || "").trim();
  if (!text) return Response.json({ error: "Pehle kahani likho." }, { status: 400 });
  if (text.length > 2500) {
    return Response.json({ error: "Sarvam voice ke liye abhi 2500 characters tak ki kahani bhejein." }, { status: 400 });
  }

  const language = "hi-IN";
  const speakerMap = {
    "Deep male narrator": "aditya",
    "Calm male narrator": "shubh",
    "Female narrator": "ritu"
  };
  const speaker = speakerMap[body.voice] || "aditya";

  try {
    const upstream = await fetch("https://api.sarvam.ai/text-to-speech", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-subscription-key": apiKey
      },
      body: JSON.stringify({
        text,
        language_code: language,
        speaker,
        model: "bulbul:v3",
        output_audio_codec: "mp3",
        speech_sample_rate: 24000,
        pace: 0.95,
        temperature: 0.65
      })
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const message = result?.error?.message || result?.message || `Sarvam API error (${upstream.status})`;
      return Response.json({ error: message }, { status: upstream.status });
    }

    const audioBase64 = result?.audios?.[0];
    if (!audioBase64) {
      return Response.json({ error: "Sarvam se audio nahi mila. Dobara try karein." }, { status: 502 });
    }

    return Response.json({ audioBase64, mimeType: "audio/mpeg" });
  } catch (error) {
    return Response.json({ error: "Voice service se connection nahi ho paya. Internet check karke dobara try karein." }, { status: 502 });
  }
};
